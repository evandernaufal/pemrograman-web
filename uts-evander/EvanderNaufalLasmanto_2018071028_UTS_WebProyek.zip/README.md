Pembuat :   Evander Naufal Lasmanto
            2018071028
            Program Studi Informatika
            Universitas Pembangunan Jaya

Halaman web ini merupakan halaman web portfolio pembuat
Web ini dibuat menggunakan HTML, Bootstrap, CSS, PHP, dan JavaScript serta membutuhkan akses internet untuk tampilan terbaik.

Terdapat 2 bagian pada web ini yaitu:
1. Halaman website (index.php)
    Pada halaman ini, guess dapat melihat portfolio yang ditampilkan serta dapat mengirimkan pesan ke Evander
    Terdapat 6 menu yaitu:
    1) Home
        Berisikan nama pemilik portfolio
    2) About Me
        Berisikan data identitas
    3) My Education
        Berisikan sejarah pendidikan
    4) Skills
        Berisikan kemampuan yang dimiliki dalam bentuk bar
    5) Creation
        Berisikan karya dari pemilik portfolio
    6) Contact
        Berisikan data kontak untuk menghubungi serta menuliskan pesan langsung ke pemilik portfolio
2. Halaman admin (login-adm.php)
    Pada halaman ini, admin dapat mengedit seluruh web title, title, subtitle, dan content, serta dapat membaca pesan yang dikirim oleh guess. Admin diharuskan untuk login terlebih dahulu sebelum memasuki web admin. Adapun akun admin ialah:
    
    USERNAME : admin
    PASSWORD : admin123

Seluruh data yang berada di web dan dapat diedit oleh admin, disimpan pada database dengan nama "utsevander" yang di dalamnya terdapat beberapa table.

Terimakasih ~ Salam Evander Naufal