<style>
  .footer {
    left: 0;
    bottom: 0;
    width: 100%;
    padding-top: 20px;
    padding-bottom: 20px;
    background-color: #212529; 
    color: white;
    text-align: center;
  } 
</style>
<div class="footer">
  <p>Copyright © FALEVAN</p>
</div>